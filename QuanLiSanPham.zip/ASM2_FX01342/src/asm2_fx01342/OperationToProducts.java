package asm2_fx01342;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class OperationToProducts {
    // Search index of element of product in Linked list, if not founf then return-1
    public int index(Products p, MyList<Products> list) {
        if (list == null) {
            return -1;
        }
        return index(p, list);
    }

    // Cread a product have:(ID, name, quantity, price) that input from keyboard

    public Products createProduct() {
        Products p = new Products();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap vao ma sp");
        p.Code = scanner.next();
        System.out.println("Nhap vao ten sp ");
        p.Name = scanner.next();
        System.out.println("Nhap vao so luong sp  ");
        p.Quantity = scanner.nextInt();
        System.out.println("Nhap vao gia sp");
        p.Price = scanner.nextDouble();
        return p;
    }
    // Wite all product of Linked List to file

    public void writeAllItemsToFile(String fileName, MyList<Products> list) {
        try {
            File file = new File(fileName);
            FileWriter fw = new FileWriter(file.getAbsoluteFile(), false);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Products p : list) {// duyet tung phan tu co trong list
                bw.write(p.Code + "; " + p.Name + "; " + p.Quantity + " ;" + p.Price);// sau moi vong lap, file se ghi
                                                                                      // vo du lieu theo thu tu
                bw.newLine();
            }
            bw.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   
    // Read all products from fike and save to Linked List ( Insert at tail of
    // Linked List), infor of a product in a line (

    public void getAllItemsFromFile(String fileName, MyList<Products> list) {
        list.Clear();

        try {
            String thisLine = "";
            File file = new File(fileName);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            list.Clear();
            while ((thisLine = br.readLine()) != null) {
                thisLine = thisLine.trim();
                if (!thisLine.isEmpty()) {
                    String[] strings = thisLine.split(";");
                    list.InsertToHead(new Products(strings[0].trim(), strings[1].trim(),
                            Integer.parseInt(strings[2].trim()), Double.parseDouble(strings[3].trim())));
                }
            }
            list.Traverse();
            br.close();
            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getAllItemsFromFile(String fileName, MyStack<Products> stack) {
        stack.Clear();
        try {
            String thisLine = "";
            File file = new File(fileName);
            FileReader fr = new FileReader(file);
            BufferedReader bf = new BufferedReader(fr);
            stack.Clear();
            while ((thisLine = bf.readLine()) != null) {
                thisLine = thisLine.trim();
                if (!thisLine.isEmpty()) {
                    String[] strings = thisLine.split(";");
                    stack.Push(new Products(strings[0].trim(), strings[1].trim(), Integer.parseInt(strings[2].trim()),
                            Double.parseDouble(strings[3].trim())));
                }
            }
            stack.Traverse();
            bf.close();
            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getAllItemsFromFile(String fileName, MyQueue<Products> queue) {
        queue.Clear();
        try {
            String thisLine = "";
            File file = new File(fileName);
            FileReader fr = new FileReader(file);
            BufferedReader bf = new BufferedReader(fr);
            queue.Clear();
            while ((thisLine = bf.readLine()) != null) {
                thisLine = thisLine.trim();
                if (!thisLine.isEmpty()) {
                    String[] strings = thisLine.split(";");
                    queue.Enqueue(new Products(strings[0].trim(), strings[1].trim(),
                            Integer.parseInt(strings[2].trim()), Double.parseDouble(strings[3].trim())));
                }
            }
            queue.Traverse();
            bf.close();
            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Add a new product into tail of Linked List

    public void addLast(Products p, MyList<Products> list) {
        list.InsertToTail(p);
    }

    // Display infor of all product on Linked list

    public void displayAll(MyList<Products> list) {
        list.Traverse();
    }

    // Display info of all product on stack
    public void displayALLStack(MyStack<Products> stack) {
        stack.Traverse();
    }

    // Display info of all product on queue
    public void displayAllQueue(MyQueue<Products> queue) {
        queue.Traverse();
    }

    // Search first element by ID
    public void searchByCode(MyList<Products> list) {
        System.out.println("Nhap vao ID can tim: ");
        Scanner scanner = new Scanner(System.in);
        String ID = scanner.nextLine();
        boolean check = false;
        // tạo 1 ds chứa các phần tử tìm thấy, chỗ này em biết làm ko?
        MyList<Products> m = new MyList<>();
        Node<Products> h = list.head;
        while (h != null) {
            if (h.data.Code.compareTo(ID) == 0) {
                // phần tử này tìm thấy, thêm vào ds tìm thấy, em code di
                m.InsertToTail(h.data);
                check = true;
                break;
            }

            h = h.next;
        }

        if (check == true) {
            // DisPlayAll(list); day la in toan bo ds
            // hiện ds tìm thấy
            displayAll(m);
        } else {
            System.out.println("Khong tim thay ID");
        }
    }

    // Delete first element by ID (=ID)

    public void deleteByCode(MyList<Products> list) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap vao ID can xoa:");
        String ID = scanner.nextLine();
        boolean check = false;
        Node<Products> h = list.head;
        while (h != null) {
            if (h.data.Code.compareTo(ID) == 0) {
                // list.DeleteElement(list.head.data); code này luon là head
                // Note cần xóa là note tìm thấy
                // node em dang kiem tra là h => node tìm thấy là h =
                list.DeleteElement(h.data); // Xóa node tìm thấy
                check = true;
            }
            h = h.next;
        }
        if (check == true) {
            displayAll(list);
            System.out.println("Done");
        } else {
            System.out.println("Khong tim thay ID de xoa");
        }
    }

    // Sort by ID

    public void sortByCode(MyList<Products> list) {
        Node<Products> p = list.head;
        Node<Products> q = new Node<>();
        MyList<Products> m = new MyList<>();
        while (p != list.tail) {
            q = list.head;// gán giá trị hiện tại của q = giá trị ở vị trí head chạy đến p(tail)
            while (q != p) {// duyệt xem q có p(tail)?
                if (q.data.Code.compareTo(q.next.data.Code) > 0) { // so sánh
                    list.Swap(q, q.next);// hoán đổi vị trí các Node
                }
                q = q.next;// chuyển tiếp sang phần tủ kế tiếp
            }
            p = p.next;// chuyển sang vị trí tiếp theo của p => head,next
        }
    }

    // Add new product to head of Linked list

    public void addFirst(Products p, MyList<Products> list) {
        list.InsertToHead(p);
    }

    // Conver to binary

    public void Convert_Binary(int i) {
        if(i!=0){
            Convert_Binary(i/2);// lien tiep chia cho 2 cho den khi thuong = 0
            System.out.print(i%2);// chia lay du va in du ra man hinh
        }
    }

}
