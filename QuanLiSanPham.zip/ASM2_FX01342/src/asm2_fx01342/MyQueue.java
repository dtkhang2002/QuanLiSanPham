package asm2_fx01342;

import java.util.Iterator;

public class MyQueue<T> {
    Node<T> head, tail;

    MyQueue() {
        head = tail = null;
    }

    boolean isEmpty() {
        return head == null;
    }
    public Iterator<T> iterator() {
        return new QueueIterator<T>(this);
    }
    // enqueue
    public void Enqueue(T data) {
        Node p = new Node<>(data);
        if (isEmpty()) {
            head = tail = p;
            return;
        }
        tail.next = p;
        tail = p;
    }

    // dequeue
    public T Dequeue() {
        T k = head.data;
        if (isEmpty()) {
            return null;
        } else {
            head = head.next;
            if (head == null) {
                tail = null;
            }
        }
        return k;
    }

    public void Display(Node<T> p) {
        System.out.print(p.data + " ");
        System.err.println();
    }

    public void Traverse() {
        Node<T> p = this.head;
        while (p != null) {
            Display(p);
            p = p.next;
        }
    }

    void Clear() {
        head = tail = null;
    }
    class QueueIterator<T> implements Iterator<T> {
        Node<T> current;

        public QueueIterator(MyQueue<T> queue) {
            current = queue.head;// lay vi tri hien tai cua head
        }

        // returns false if next element does not exist
        // returns true if exist the next element to traverse
        public boolean hasNext() {
            return current != null;
        }

        // return current data and update data in pointer
        public T next() {
            T data = current.data;// gán dữ liệu ở current hiện tại vào data
            current = current.next;// update dữ liệu ở current hiện tại vô current.next
            return data;
        }

        // implement if needed
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }
}
