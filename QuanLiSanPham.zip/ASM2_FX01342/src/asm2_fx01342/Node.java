package asm2_fx01342;

public class Node<T> {
    T data;
    Node<T> next;

    Node(T data) {
        this.data = data;
    }

    Node() {

    }
}
