package asm2_fx01342;

import java.util.Scanner;

public class ASM2_Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        OperationToProducts op = new OperationToProducts();
        MyList<Products> list = new MyList<>();
        MyStack<Products> stack = new MyStack<>();
        MyQueue<Products> queue = new MyQueue<>();
        while (true) {
            Menu();
            choice = scanner.nextInt();
            if (choice == 0) {
                System.out.println("Goodbye and have a nice day my friends");
                break;
            }
            switch (choice) {
                case 1:
                    System.out.println("Display all products from link list");
                    System.out.println("Code \t Name \t Quantity \t Price");
                    op.getAllItemsFromFile("data.txt", list);
                    break;
                case 2:
                    Products p = op.createProduct();
                    op.addLast(p, list);
                    break;
                case 3:
                    System.out.println("List after being added: \n");
                    op.displayAll(list);
                    break;
                case 4:
                    op.writeAllItemsToFile("data.txt", list);
                    System.out.println("Done");
                    break;
                case 5:
                    op.searchByCode(list);
                    break;
                case 6:
                    op.deleteByCode(list);
                    break;
                case 7:
                    op.sortByCode(list);
                    System.out.println("List after being sorted");
                    op.displayAll(list);
                    break;
                case 8:
                    Node<Products> l = list.head;
                    while(l!=null){
                        op.Convert_Binary(l.data.Quantity);
                        System.out.println();
                        l = l.next;
                    }
                    break;
                case 9:
                    System.out.println("Display all the products from stack");
                    System.out.println("Code \t Name \t Quantity \t Price");
                    op.getAllItemsFromFile("data.txt", stack);
                    break;
                case 10:
                    System.out.println("Display all the products from the queue");
                    System.out.println("Code \t Name \t Quantity \t Price");
                    op.getAllItemsFromFile("data.txt", queue);
                    break;
                default:
                    System.err.println("Please type again");

            }
        }
    }

    static void Menu() {
        System.out.println("1. Read the data from a constant file text and save to LinkList");
        System.out.println("2. Add a new data to the LinkList(tail of the LinkList");
        System.out.println("3. Display the data");
        System.out.println("4. Save to file");
        System.out.println("5. Find by ID");
        System.out.println("6. Delete by ID");
        System.out.println("7. Sort by ID");
        System.out.println("8. Convert the amount of data to binary number");
        System.out.println("9. Read the data from file and save to stack. Display the stack");
        System.out.println("10. Read the data from file and save to queue. Display the queue");
        System.out.println("0. Exit the program");
    }
}
