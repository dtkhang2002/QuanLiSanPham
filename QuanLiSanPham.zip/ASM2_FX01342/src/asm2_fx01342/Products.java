package asm2_fx01342;

public class Products {
    String Code;
    String Name;
    double Price;
    int Quantity;

    Products(String Code, String Name, int Quantity, double Price) {
        this.Code = Code;
        this.Name = Name;
        this.Price = Price;
        this.Quantity = Quantity;
    }

    Products() {

    }

    @Override
    public String toString() {
        return Code + "\t" + Name + "\t" + Quantity + "\t" + Price + "\n";
    }

}
