package asm2_fx01342;

import java.util.Iterator;

public class MyList<T> implements Iterable<T> {
    Node<T> head, tail;
    int length;

    MyList() {
        head = tail = null;
    }

    boolean isEmpty() {
        return head == null;
    }

    // return Iterator instance
    public Iterator<T> iterator() {
        return new ListIterator<T>(this);
    }

    // insert to head
    public void InsertToHead(T m) {
        Node n = new Node(m);
        length++;
        if (isEmpty()) {
            head = tail = n;
            return;
        }
        n.next = head; // change the position of head
        head = n;
    }
    // insert to tail
    public void InsertToTail(T info) {
        Node n = new Node<>(info);
        length++;
        if (isEmpty()) {
            head = tail = n;
            return;
        }
        tail.next = n;// change the position
        tail = n;
    }

    // insert after the position
    public void InsertAfterThePosition(int position, T info) {
        if (position < 0) {
            System.out.println("Invalid position");
            return;
        }
        if (isEmpty()) {
            InsertToHead(info);
            return;
        }
        if (position >= length) {
            InsertToTail(info);
            return;
        }
        int i = 0;
        Node cur = head;
        while (i < position - 1) {
            i++;
            cur = cur.next;
        }
        Node newNode = new Node(info);
        newNode.next = cur.next;
        cur.next = newNode;
        length++;
    }

    // delete element has value = x
    public void DeleteElement(T info) {
        // TH không có phần tử nào
        // TH có phần tử, tìm phần tử xóa
        Node prev = null;
        Node curr = this.head;// tim node can xoa
        while (curr != null && curr.data != info) {
            prev = curr;
            curr = curr.next;

        }
        if (curr == null)
            return;
        if (prev == null) // xoa dau
            head = curr.next;// head = head.next
        else // xoa vi tri bat ky
            {prev.next = curr.next;}
        //tail = head.next;
        //tail = prev.next;
        // tail.next = tail;
        // tail = curr.next;
        
        if(curr==tail && curr.data == info)// check if the node we want to delete is tail.
         tail = prev;
       // System.out.println(tail.data);
    }

    // swap
    public void Swap(Node<T> x1, Node<T> x2) {
        T y;
        y = x1.data;
        x1.data = x2.data;
        x2.data = y;
    }

    // Delete all the LinkList
    public void Clear() {
        head = tail = null;
    }

    // display
    public void Display(Node p) {
        System.out.print(p.data + " ");
        System.out.println();
    }

    // traverse
    public void Traverse() {
        Node p = this.head;
        while (p != null) {
            Display(p);
            p = p.next;
        }
    }

    class ListIterator<T> implements Iterator<T> {
        Node<T> current;

        public ListIterator(MyList<T> list) {
            current = list.head;// lay vi tri hien tai cua head
        }

        // returns false if next element does not exist
        // returns true if exist the next element to traverse
        public boolean hasNext() {
            return current != null;
        }

        // return current data and update data in pointer
        public T next() {
            T data = current.data;// gán dữ liệu ở current hiện tại vào data
            current = current.next;// update dữ liệu ở current hiện tại vô current.next
            return data;
        }

        // implement if needed
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }
}
